ANAS CITY 3D WEBSITE

Files:
- index.html    Home page
- game.html     Playable game
- about.html    About page
- privacy.html  Privacy policy
- style.css     Website styling

PUBLISHING:
Upload all files together to your static website host. The homepage must be index.html.
After publishing, test every navigation link and make sure the game loads.

ADSENSE:
Do not add made-up AdSense IDs. After your AdSense account is approved/ready, use the exact code Google gives you and follow Google's placement and policy rules.

IMPORTANT:
The current game loads Three.js from jsDelivr, so visitors need an internet connection for the 3D engine.
